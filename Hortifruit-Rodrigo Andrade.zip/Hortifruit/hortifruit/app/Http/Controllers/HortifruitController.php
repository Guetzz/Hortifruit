<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Hortifruit;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Response;
use App\Http\Controllers;


class HortifruitController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $dadosFrutas = Hortifruit::All();
        $contador = $dadosFrutas->count();

        return 'Frutas: '.$contador.  $dadosFrutas. Response()->json([], Response::HTTP_NO_CONTENT);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $dadosFrutas = $request->All();

        $valida = Validator::make($dadosFrutas, [
            'nomeFruta'=> 'required',
            'corFruta'=> 'required',
        ]);

        if($valida->fails()){
            return 'Dados inválidos'.$valida->errors(true). 500;
        }
            $frutasBanco = Hortifruit::create($dadosFrutas);
        if($frutasBanco){
            return 'Frutas cadastradas '.Response()->json([], Response::HTTP_NO_CONTENT); 
        }else{
            return 'Frutas não cadastradas '.Response()->json([], Response::HTTP_NO_CONTENT);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $frutasBanco = Hortifruit::find($id);
        $contador = $frutasBanco->count();

        if($frutasBanco){
            return 'Frutas  encontradas: '.$contador.' - '.$frutasBanco.response()->json([],Response::HTTP_NO_CONTENT); 
        }else{
            return 'Frutas Não localizadas.'.response()->json([],Response::HTTP_NO_CONTENT); 
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $frutasDados= $request->All();

        $valida = Validator::make($frutasDados,[
            'nomeFruta' => 'required',
            'corFrutas' => 'required',
        ]);

        if($valida->fails()){
            return 'Dados incompletos '.$valida->errors(true). 500;
        }

        $frutasBanco = Hortifruit::find($id);
        $frutasBanco->nomeFruta = $frutasDados['nomeFruta'];
        $frutasBanco->corFruta = $frutasDados['corFruta'];

        $RegistrosFrutas = $frutasBanco->save();
        if($RegistrosFrutas){
            return 'Dados alterados com sucesso.';
        }else{  
            return 'Dados não alterados no banco de dados'.response()->json([],Response::HTTP_NO_CONTENT);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $frutasBanco = Hortifruit::find($id);
        if($frutasBanco){
            $frutasBanco->delete();
            return 'A Fruta foi deletada com sucesso.'.response()->json([],Response::HTTP_NO_CONTENT); 
        }else{
            return 'A Fruta Não foi deletada com sucesso.'.response()->json([],Response::HTTP_NO_CONTENT); 
        }
    }
}
